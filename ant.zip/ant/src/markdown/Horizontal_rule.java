package markdown;

import java.util.ArrayList;

public class Horizontal_rule extends Node{

	Horizontal_rule(String s) {
		strings=s;
		// TODO Auto-generated constructor stub
	}

}
