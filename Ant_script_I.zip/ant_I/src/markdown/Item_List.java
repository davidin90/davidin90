package markdown;

import java.util.ArrayList;

public class Item_List extends Node{

	Item_List(String s) {
		strings=s;
		// TODO Auto-generated constructor stub
	}

}
