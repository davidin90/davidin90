package markdown;

import java.util.ArrayList;

public class Quoted_block extends Node{

	Quoted_block(String s) {
		strings=s;
		// TODO Auto-generated constructor stub
	}

}
