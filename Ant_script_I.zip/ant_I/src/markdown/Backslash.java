package markdown;

import java.util.ArrayList;

public class Backslash extends Token{

	Backslash(String s) {
		strings=s;
		// TODO Auto-generated constructor stub
	}
}
