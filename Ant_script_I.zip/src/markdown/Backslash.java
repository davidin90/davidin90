package markdown;

import java.util.ArrayList;

public class Backslash extends Node{
	Backslash(){
	}
	Backslash(String[] s) {
		super();
		// TODO Auto-generated constructor stub
	}
}
