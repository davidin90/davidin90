package markdown;

public class Strong {

}
