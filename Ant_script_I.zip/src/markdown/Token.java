package markdown;

public class Token implements MDElement{
	public void accept(MDElementVisitor v){
		v.visitToken(this);
	}
}
