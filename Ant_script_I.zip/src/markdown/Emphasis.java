package markdown;

public class Emphasis {

}
