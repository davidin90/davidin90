package markdown;

import java.io.IOException;
import java.util.ArrayList;

public class Document implements MDElement{
	ArrayList<String[]> documentlist = null;
	
	Document(String[] s) throws IOException{
	//	new Node(s, 1, );
		documentlist.add(s);
	}
	public ArrayList<String[]> getDocument(){
		return documentlist;
	}
	public void accept(MDElementVisitor v){
		v.visitDocument(this);
	}
}
