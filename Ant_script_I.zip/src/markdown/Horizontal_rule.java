package markdown;

import java.util.ArrayList;

public class Horizontal_rule extends Node{

	Horizontal_rule(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
