package markdown;

import java.util.ArrayList;

public class Image extends Token{

	Image(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
