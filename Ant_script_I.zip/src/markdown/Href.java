package markdown;

import java.util.ArrayList;

public class Href extends Token{

	Href(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
