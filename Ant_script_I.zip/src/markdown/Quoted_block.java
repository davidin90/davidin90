package markdown;

import java.util.ArrayList;

public class Quoted_block extends Node{

	Quoted_block(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
