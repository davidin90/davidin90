package markdown;

import java.util.ArrayList;

public class Code extends Node{

	Code(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
