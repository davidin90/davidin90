package markdown;

import java.util.ArrayList;

public class Item_List extends Node{

	Item_List(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
