package markdown;

import java.util.ArrayList;

public class Line_Break extends Node{

	Line_Break(ArrayList<String[]> s) {
		super();
		// TODO Auto-generated constructor stub
	}

}
