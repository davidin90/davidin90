package markdown;

import java.util.ArrayList;

public class Block extends Node{

	Block(String s) {
		strings=s;
	}


}
