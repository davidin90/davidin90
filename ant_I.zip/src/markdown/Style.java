package markdown;

public interface Style {

}
