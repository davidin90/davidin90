package markdown;
import java.io.IOException;
import java.util.ArrayList;

public class Header extends Node{

	Header(String s) {
		super.strings=s;
	}


}
